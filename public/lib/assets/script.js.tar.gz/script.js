 url_base = window.location.href;
 jQuery(document).ready(function($) {
 
    /*$(".scroll a, .navbar-brand, .gototop,.explore").click(function(event){   
    event.preventDefault();
    $('html,body').animate({scrollTop:$(this.hash).offset().top}, 600,'swing');
    $(".scroll li").removeClass('active');
    $(this).parents('li').toggleClass('active');
    });*/
    $("#hechos").select2({
        minimumResultsForSearch: Infinity,
        placeholder: "Busque los ingredientes",
        allowClear: true,
        ajax: {
            url: url_base+"/index.php/hechos/buscar",
            dataType: 'json',
            delay: 250,
            data: function (params) {
              return {
                q: params.term, // search term
                page: params.page
              };
            },
            processResults: function (data, page) {
              // parse the results into the format expected by Select2.
              // since we are using custom formatting functions we do not need to
              // alter the remote JSON data
              return {
                results: data.items
              };
            },
            cache: true
          }
    });

    $(".gototop ").addClass('oculto');

    $(".select2-container, .select2-search__field").css("width", "100%");
});

$(document).on("mouseover mouseout", ".conocimiento", function(){
    $(this).find(".nombre_conocimiento").toggleClass("oculto");
});






var wow = new WOW(
  {
    boxClass:     'wowload',      // animated element css class (default is wow)
    animateClass: 'animated', // animation css class (default is animated)
    offset:       0,          // distance to the element when triggering the animation (default is 0)
    mobile:       true,       // trigger animations on mobile devices (default is true)
    live:         true        // act on asynchronously loaded content (default is true)
  }
);
wow.init();




$('.carousel').swipe( {
     swipeLeft: function() {
         $(this).carousel('next');
     },
     swipeRight: function() {
         $(this).carousel('prev');
     },
     allowPageScroll: 'vertical'
 });


$(document).on("click", ".conocimiento", function(){
    id_c = $(this).attr("id-c");
    //console.log(url_base);
    $.post(url_base+"/index.php/conocimientos/datos", {
        id:id_c
    }, function(data, textStatus, xhr) {
        $("#nombre_conocimiento").html(data[0].conocimiento);
        $("#descripcion_conocimiento").html(data[0].descripcion);
        $("#imagen_conocimiento").attr("src", url_base+"/uploads/"+data[0].imagen);
        $("#modal_conocimiento").modal();
    },'json');
});




// map

